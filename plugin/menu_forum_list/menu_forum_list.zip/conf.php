<?php

return 	array (
	'name' => '分版块看帖',	// 插件名
	'brief' => '每个版块调用若干篇主题，导航栏小三角进入。',
	'version' => '1.0',		// 插件版本
	'bbs_version'=>'2.0.2',		// 插件支持的 Xiuno BBS 版本
);
?>