<?php

return 	array (
	'name' => '导航栏版块列表',	// 插件名
	'brief' => '每个版块调用若干篇主题。',
	'version' => '1.0',		// 插件版本
	'bbs_version'=>'2.0.2',		// 插件支持的 Xiuno BBS 版本
);
?>